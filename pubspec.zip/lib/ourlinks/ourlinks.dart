const String loginUrl = 'http://atawfiq1.pythonanywhere.com/api/login/';
const String registerUrl = 'http://atawfiq1.pythonanywhere.com/api/register/';
const String productUrl =
    'http://atawfiq1.pythonanywhere.com/api/product_list/';
